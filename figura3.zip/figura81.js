i = 1;

while (i <= max) {
    document.write(i + ' ');
    i++;
}