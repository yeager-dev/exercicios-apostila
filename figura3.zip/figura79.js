switch (cor) {
    case 'vermelho':
        document.write('A cor ' + cor + ' em hexadecimal é: #FF00000');
        break;
    case 'verde':
        document.write('A cor ' + cor + ' em hexadecimal é: #00FF00');
        break;
    case 'azul':
        document.write('A cor ' + cor + ' em hexadecimal é: #0000FF');
        break;
    default:
        document.write('Não consta o hexadecimal desta cor')
} // fim do switch