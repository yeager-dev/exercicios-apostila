if (expressao-condicional) {
    ..executarcodigo
    ..executarcodigo
} else {
    ..executarcodigo
    ..executarcodigo
    ..executarcodigo
}