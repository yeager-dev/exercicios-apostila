for (var i = 1; i <= max; i++) {
        document.write(i + ' ');
}