switch (expressao) {
    case n1:
        [bloco de código 1]
        break;
    case n2:
        [bloco de código 2]
        break;
    case [...n]:
        [bloco de código n]
        break;
    default:
        [bloco de código caso não seja nenhuma das opções anteriores]    
}