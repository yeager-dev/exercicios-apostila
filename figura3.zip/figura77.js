var resultado = 0;

if (v2 > 0) {
    resultado = v1 / v2;
    alert(v1 + "/" + v2 + "= " +  resultado);
} else {
    alert("Não é possível dividir por 0");
}