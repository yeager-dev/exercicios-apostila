if (condicao) {
    // bloco de código
}

ou

if (condicao) {
    // bloco de código 1
} else {
    // bloco de código 2
}